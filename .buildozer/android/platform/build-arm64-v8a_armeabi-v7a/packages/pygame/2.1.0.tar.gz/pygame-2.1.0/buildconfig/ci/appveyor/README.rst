Appveyor is a service we use to build windows binaries for pygame.


https://ci.appveyor.com/project/pygame/pygame-temp-m8dun